Written by Elaine Cui and Adam Liu
CUI00122 and LIU02390

Each individual pieces were created by Adam, Elaine wrote board and game. We worked together to debug and fix all code.

To compile our code, in the terminal or command prompt, enter in "javac Game.java" once in the correct directory depending on where the java files are saved.
Then, enter in "java Game" to call the interpreter to run the code.

Assumptions include that the user will only input single digits in the form "0 2 4 3" for example.

There is an additional feature that if the user enters an invalid move, they will be prompted to reenter until correct.

No known bugs or defects.

No outside sources.

“I certify that the information contained in this README file is complete and accurate. I have both read and followed the course policies
in the ‘Academic Integrity - Course Policy’ section of the course syllabus.”

Elaine Cui
Adam Liu