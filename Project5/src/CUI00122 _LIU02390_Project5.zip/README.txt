Written by Elaine Cui and Adam Liu
CUI00122 and LIU02390

Elaine worked on the first hash function and parts of the display method. Adam worked on the second hash function and main. We both did the final hash function, editing, and comments.

To compile our code, in the terminal or command prompt, enter in "javac HashTable.java"  once in the correct directory depending on where the java files are saved.
Then, enter in "java HashTable"  to call the interpreter to run the code.

There is the assumption that the files will read in tokens that are Strings. There is also the assumption that the tokens are groups of characters. Another
assumption is that no duplicates are allowed.

There are no additional features.

No known bugs or defects.

We did not use any code from TextScan that was provided for the project. NGen.java
was used in this project in order to be able to initialize the hash table with nodes.
No other outside sources was used in this project.

“I certify that the information contained in this README file is complete and accurate. I have both read and followed the course policies
in the ‘Academic Integrity - Course Policy’ section of the course syllabus.”

Elaine Cui
Adam Liu
