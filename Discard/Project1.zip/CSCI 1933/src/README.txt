Written by Elaine Cui, cui00122 and Adam Liu, liu02390

Elaine completed the Triangle.java class, and Adam completed the Rectangle.java individually. We completed the Circle.java and FractalDrawer.java together, including main.

To compile our code, in the terminal or command prompt, enter in "javac FractalDrawer.java" once in the correct directory depending on where the java files are saved.
Then, enter in "java FractalDrawer" to call the interpreter to run the code.

An assumption would be that the canvas is 800 by 800, so any lengths, heights, or radius entered should be reasonable to that size.
As a result, the user may need to full screen or minimize the window and reopen it for the fractal to appear.
Another assumption is that the colors used are RED, CYAN, BLUE, MAGENTA, YELLOW, and GREEN. They are cycled through the different levels, so that each level has a different color.

There are no other additional features other than the ones outlined in the project guidelines.

There are no known bus or problems with the program.

There were no outside sources used in the program.

“I certify that the information contained in this README file is complete and accurate. I have both read and followed the course policies
in the ‘Academic Integrity - Course Policy’ section of the course syllabus.”

Elaine Cui
Adam Liu