Written by Elaine Cui and Adam Liu
CUI00122 and LIU02390

Elaine wrote most of the ArrayList class. Adam wrote most of the LinkedList class. We worked together to debug and write the analysis.

To compile our code, in the terminal or command prompt, enter in "javac ArrayListTest.java" or "javac LinkedListTest.java" once in the correct directory depending on where the java files are saved.
Then, enter in "java ArrayListTest" or "java LinkedListTest" to call the interpreter to run the code. This will call the tests to test ArrayList.java or LinkedList.java that you can also compile by going to
the terminal or commad prompt, enter in "javac ArrayList.java" or "javac LinkedList.java". Once in correct directory, enter "java ArrayList" or "java LinkedList" to call the interpreter.

There is the assumption that the test classes work and are compiled correctly. It is also assumed that the list is considered sorted when no elements are in it or only one element is in it.

There are no additional features.

No known bugs or defects.

No outside sources other than the provided code for the class.

“I certify that the information contained in this README file is complete and accurate. I have both read and followed the course policies
in the ‘Academic Integrity - Course Policy’ section of the course syllabus.”

Elaine Cui
Adam Liu