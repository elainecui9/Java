Written by Elaine Cui and Adam Liu
CUI00122 and LIU02390

Elaine wrote most of the Print and parts of the Solve method. Adam wrote most of the Make method and parts of the Solve method. We worked together to debug and make sure everything was correct..

To compile our code, in the terminal or command prompt, enter in "javac MyMaze.java"  once in the correct directory depending on where the java files are saved.
Then, enter in "java MyMaze"  to call the interpreter to run the code.

There is the assumption that the user will enter in a number for the rows and cols wanted.

There are no additional features.

No known bugs or defects.

No outside sources other than the provided code for the class.

“I certify that the information contained in this README file is complete and accurate. I have both read and followed the course policies
in the ‘Academic Integrity - Course Policy’ section of the course syllabus.”

Elaine Cui
Adam Liu